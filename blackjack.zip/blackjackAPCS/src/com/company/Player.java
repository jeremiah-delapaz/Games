package com.company;

import java.util.ArrayList;

public class Player {
    private ArrayList<Card> hand;
    private int score;


    public Player()
    {
        hand = new ArrayList<Card>();//initializes array list
        score = 0;
    }

    public void addCard(Card inCard)
    {
        hand.add(inCard);
    }

    public int getScore()
    {
        score = 0;// without the score would just keep incrementing everytime called
        for(int i = 0; i < hand.size(); i++)
        {
            score += hand.get(i).getValue();
        }
        return score;
    }

    public ArrayList<Card> getHand()
    {
        return hand;
    }
}
