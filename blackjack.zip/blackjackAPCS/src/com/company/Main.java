package com.company;
import java.util.Scanner;

public class Main {

    public static boolean checkWin(Player player)//Checks if player wins
    {
        if(player.getScore()==21)
        {
            return true;
        }
        return false;
    }
    public static boolean checkLoss (Player player)//checks if player goes over 21
    {
        if(player.getScore()>21)
        {
            return true;
        }
        return false;
    }
    public static void changeAce(Player player)//changes ace to 1 if over 21
    {
        int checkforAce = 0;
        for(int i = 0; i<player.getHand().size(); i++)
        {
            if(player.getHand().get(i).getSuit().equals("ace"))
            {
                checkforAce = 1;
            }
        }

        while(player.getScore()>21 && checkforAce ==1)
        {
            for(int i = 0; i<player.getHand().size(); i++)//changes all of the necessary aces
            {
                if(player.getHand().get(i).getSuit().equals("ace"))
                {
                    player.getHand().get(i).changeValue(1);
                }
            }
        }
    }

    public static void main(String[] args) {
	// write your code here
        int checkplayagain=0;
while(checkplayagain==0) {//continues if player wants to play again
    Deck playingCards = new Deck();
    playingCards.shuffle();

    Player Andy = new Player();
    Player Dealer = new Player();
    int checkPlay = 0;
    int checkHS = 0;//variable to stop if they no longer want to hit
    int checkdealer = 0; //variable to check if dealer should stop hitting
    String userChoice;
    String playagain;


    Andy.addCard(playingCards.getTopCard());//deals cards
    Dealer.addCard(playingCards.getTopCard());
    Andy.addCard(playingCards.getTopCard());
    Dealer.addCard(playingCards.getTopCard());
    while (checkPlay != 1) {//checks if play is to continue, keeps loop out of checking win condition

        System.out.println("your hand: " + Andy.getHand());
        System.out.println("your total: " + Andy.getScore());
        changeAce(Andy);


        while (checkHS == 0) {//sees if player still wants to hit

            System.out.println("hit[H] or stand[S]");
            Scanner hitOrStand = new Scanner(System.in);
            userChoice = hitOrStand.next();
            if (userChoice.equals("H")) {
                Andy.addCard(playingCards.getTopCard());
                //System.out.println("your total: " + Andy.getScore());
                System.out.println("your hand: " + Andy.getHand());
            } else if (userChoice.equals("S")) {
                checkHS = 1;
            }
            System.out.println(Andy.getScore());
            changeAce(Andy);

            System.out.println(Andy.getScore());
            if (checkWin(Andy)) {
                System.out.println("you win.");
                checkPlay = 1;
                checkHS = 1;

                checkdealer = 1;
            }
            if (checkLoss(Andy)) {
                System.out.println("you lose.");
                checkPlay = 1;
                checkHS = 1;

                checkdealer = 1;
            }
        }
        while (checkdealer == 0) {
            System.out.println("dealer's total: " + Dealer.getScore());
            System.out.println("dealer's hand: " + Dealer.getHand());
            changeAce(Dealer);

            if (Dealer.getScore() < 17) {//only hits if under  17
                Dealer.addCard(playingCards.getTopCard());
                System.out.println("dealer's total: " + Dealer.getScore());
                System.out.println("dealer's hand: " + Dealer.getHand());
            }
            if (Dealer.getScore() >= 17) {
                checkdealer = 1;
            }
            if (checkWin(Dealer)) {
                System.out.println("dealer wins.");
                checkdealer = 1;
                checkPlay = 1;
            }
            if (checkLoss(Dealer)) {
                System.out.println("dealer lost.");
                checkdealer = 1;
                checkPlay = 1;
            }

        }
        if (Dealer.getScore() > Andy.getScore() && checkPlay != 1) {//win conditions
            System.out.println("Dealer wins");
        } else if (Dealer.getScore() < Andy.getScore() && checkPlay != 1) {
            System.out.println("Player wins");
        } else if (Dealer.getScore() == Andy.getScore()) {
            System.out.println("Tie");
        }
        checkPlay = 1;//exits out of loop of the game but stays within loop of whether or not they want to play a new game
    }
    System.out.println("would you like to play again? [Y] or [N]");
    Scanner playAgain = new Scanner(System.in);
    playagain = playAgain.next();
    if (playagain.equals("N")) {
        checkplayagain = 1;
    }
}

    }
}
