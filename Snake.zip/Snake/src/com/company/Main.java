package com.company;
import javax.swing.*;

public class Main {

    public static void main(String[] args) {
	// write your code here

        GamePlay frame = new GamePlay();
        frame.setTitle("Move with keys");
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        frame.requestFocus();   // set the focus to JFrame to receive KeyEvent
        frame.start();



    }
}
