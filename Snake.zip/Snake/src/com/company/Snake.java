package com.company;
import java.awt.*;
import java.util.ArrayList;

public class Snake  {
    public static final Color headColor = new Color(1, 0, 255, 255);
    public static final Color bodyColor = new Color(0, 188, 255, 255);

    public static final int OBJECT_SIZE = 10;

    private int size = OBJECT_SIZE;
    private ArrayList<SnakeDot> snakeDots;
    SnakeDot head;
    public boolean left = false;
    public boolean right = true;
    public boolean up = false;
    public boolean down= false;
    private String previousDirection;
    public Snake(int x, int y)
    {
        snakeDots = new ArrayList<SnakeDot>();
        head = new SnakeDot(x, y, headColor, true);
        snakeDots.add(head);

    }

    public SnakeDot getHead() { return head; }
    public int getheadX()
    {
        return head.getX1();
    }

    public int getheadY()
    {
        return head.getY1();
    }

    public int getLastX(){return snakeDots.get(snakeDots.size()-1).getX1();}
    public int getLastY(){return snakeDots.get(snakeDots.size()-1).getY1();}


    public void addDot(int inX, int inY)
    {
        SnakeDot a = new SnakeDot(inX, inY, bodyColor);
        snakeDots.add(a);

    }


    public void draw(Graphics g) {
        head.draw(g, size);
        for(int i = 1; i<snakeDots.size(); i++)
        {
            snakeDots.get(i).draw(g,size);
        }

    }

    public void moveLeft() {
        //right  = false;
        changeBody();
        head.moveX(-10);
    }

    public void moveRight()
    {
        //right = true; left = false; up = false; down = false;
        changeBody();
        head.moveX(10);
    }

    public void moveUp() {
        //right = false; left = false; up = true; down = false;
        changeBody();
        head.moveY(-10);
    }

    public void moveDown() {
        //right = false; left = false; up = false; down = true;
        changeBody();
        head.moveY(10);

    }

    public void changeBody()
    {

       for(int i = snakeDots.size()-1;i>0; i-- )
        {
            snakeDots.get(i).setX(snakeDots.get(i-1).getX1());
            snakeDots.get(i).setY(snakeDots.get(i-1).getY1());
            snakeDots.get(i).setRight(snakeDots.get(i-1).getRight());
            snakeDots.get(i).setLeft(snakeDots.get(i-1).getLeft());
            snakeDots.get(i).setup(snakeDots.get(i-1).getUp());
            snakeDots.get(i).setDown(snakeDots.get(i-1).getDown());
        }

    }

    public boolean getLastRight()
    {
        return(snakeDots.get(snakeDots.size()-1).getRight());
        //return right;

    }
    public boolean getLastLeft()
    {
        return(snakeDots.get(snakeDots.size()-1).getLeft());
        //return left;
    }
    public boolean getLastUp()
    {
        return(snakeDots.get(snakeDots.size()-1).getUp());
        //return up;
    }
    public boolean getLastDown()
    {
        return(snakeDots.get(snakeDots.size()-1).getDown());
       // return down;
    }

    public boolean getHeadUp(){return head.getUp();}
    public boolean getHeadDown(){return head.getDown();}
    public boolean getHeadLeft(){return head.getLeft();}
    public boolean getHeadRight(){return head.getRight();}


    public boolean detectCollisionWSelf()
    {
        for(int i = 1; i<snakeDots.size();i++)
        {
            if(head.getX1()==snakeDots.get(i).getX1() &&  head.getY1()==snakeDots.get(i).getY1())
            {
                return true;
            }

        }
        return false;
    }

    public void changeHeadDirection(String inDirection)
    {
        System.out.println("before changeDirection head = " + head);

        if(head.getDown()){previousDirection = "Down";}
        if(head.getUp()){previousDirection = "Up";}
        if(head.getLeft()){previousDirection = "Left";}
        if(head.getRight()){previousDirection = "Right";}
        if(inDirection.equals("Right"))
        {

            head.setRight(true);
            head.setLeft(false);
            head.setup(false);
            head.setDown(false);
        }
        if(inDirection.equals("Down"))
        {
            head.setRight(false);
            head.setLeft(false);
            head.setup(false);
            head.setDown(true);
        }
        if(inDirection.equals("Up"))
        {
            head.setRight(false);
            head.setLeft(false);
            head.setup(true);
            head.setDown(false);
        }
        if(inDirection.equals("Left"))
        {
            head.setRight(false);
            head.setLeft(true);
            head.setup(false);
            head.setDown(false);
        }
        System.out.println("after changeDirection head = " + head);

    }

    public String getpreviousDirection(){return previousDirection;}


}
