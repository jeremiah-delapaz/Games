package com.company;

import java.awt.*;

public class SnakeDot {


    public static final int OBJECT_SIZE = 10;
    private Color color = new Color(255, 17, 0, 253);
    private int size = OBJECT_SIZE;
    private int x1;
    private int y1;
    public boolean left;
    public boolean right;
    public boolean up;
    public boolean down;

    public SnakeDot(int inX, int inY, Color color)
    {
        x1= inX;
        y1= inY;
        this.color=color;
    }
    public SnakeDot(int inX, int inY, Color color, boolean inRight)
    {
        x1= inX;
        y1= inY;
        this.color=color;
        right = inRight;
    }
    public int getX1()
    {
        return x1;
    }

    public int getY1()
    {
        return y1;
    }

    public void setX(int x)
    {
        x1 = x;
    }

    public void setY( int y)
    {
        y1= y;
    }

    public void draw(Graphics g, int size) {
        g.setColor(color);
        g.fillOval(x1, y1, size, size);
    }

    public void moveX(int i) {

        if(i>0){right = true; left = false; up = false; down = false;}
        else{right = false; left = true; up = false; down = false;}
        x1+=i;

    }

    public void moveY(int i) {
        if(i>0){right = false; left = false; up = false; down = true;}
        else{right = false; left = false; up = true; down = false;}
        y1+=i;

    }

    public boolean getRight(){return right; }
    public boolean getLeft(){return left;}
    public boolean getUp(){return up;}
    public boolean getDown(){return down;}

    public void setRight(boolean inRight){right = inRight;}
    public void setLeft(boolean inLeft){left = inLeft;}
    public void setup(boolean inUp){up = inUp;}
    public void setDown(boolean inDown){down = inDown;}

    @Override
    public String toString() {
        return "SnakeDot{" +
                "x1=" + x1 +
                ", y1=" + y1 +
                ", left=" + left +
                ", right=" + right +
                ", up=" + up +
                ", down=" + down +
                '}';
    }
}
