package com.company;
import java.awt.*;       // Using AWT's Graphics and Color
import javax.swing.*;    // Using Swing's components and containers

public class Board extends JPanel{
    // Define constants for the various dimensions
    public static final int CANVAS_WIDTH = 400;
    public static final int CANVAS_HEIGHT = 400;
    public static final int OBJECT_SIZE = 10;
    public static final Color OBJECT_COLOR = new Color(0, 11, 255, 100);
    public static final Color appleColor = new Color(255, 0, 42, 255);
    public static final Color CANVAS_BACKGROUND = Color.GREEN;


    // The moving line from (x1, y1) initially position at the center
    private int x1 = CANVAS_WIDTH / 5;
    private int y1 = CANVAS_HEIGHT / 5;
    private int size = OBJECT_SIZE;
    private int score = 0;
    private boolean dontMove;





    private int appleX;
    private int appleY;
    private boolean gameOver = false;

    private Snake snake = new Snake( x1, y1);

    private SnakeDot apple = new SnakeDot(100,50, appleColor);



    @Override
    public void paintComponent(Graphics g) {
        //if you would like text or more or different object
        //we would put them in here
        super.paintComponent(g);


        g.setFont(new Font("Arial", Font.BOLD, 15));
        // Get font metrics for the current font
        FontMetrics fm = g.getFontMetrics();
        // Centralize the string
        String msg = "Score: "+ score;
        int msgWidth = fm.stringWidth(msg);
        int msgAscent = fm.getAscent();
        // Get the position of the leftmost character in the baseline
        // getWidth() and getHeight() returns the width and height of this component
        int msgX = getWidth() / 2 - msgWidth / 2;
        int msgY = getHeight() /20  + msgAscent / 2;
        g.drawString(msg, msgX, msgY);
        if(gameOver){g.drawString("Game Over", 100, 100);}

        setBackground(CANVAS_BACKGROUND);

       /* g.setColor(OBJECT_COLOR);
        g.fillRect(x1, y1, size, size);*/


       snake.draw(g);
       apple.draw(g,size);
    }


    public void moveLeft( ) {
        System.out.println("move left  head = " + snake.getHead());
        if(!snake.getHeadRight() ){
            System.out.println("canvas move #1 left");
            snake.moveLeft();
            return;
        }
        System.out.println("canvas move #2 left");
//        else{            if(snake.getpreviousDirection().equals("Up")){changeDirection("Up");snake.moveUp();}
//            if(snake.getpreviousDirection().equals("Down")){changeDirection("Down"); snake.moveDown();}
//            if(snake.getpreviousDirection().equals("Left")){changeDirection("Left");snake.moveLeft();}
 //           }
    }

    public void moveRight() {
        if(!snake.getHeadLeft()){
            snake.moveRight();
        }
//        else{            if(snake.getpreviousDirection().equals("Up")){changeDirection("Up");snake.moveUp();}
//            if(snake.getpreviousDirection().equals("Down")){snake.moveDown();}
//
//            if(snake.getpreviousDirection().equals("Right")){changeDirection("Right");snake.moveRight();}}
    }

    public void moveUp() {
        if(!snake.getHeadDown()){
        snake.moveUp();}
//        else{
//            if(snake.getpreviousDirection().equals("Up")){ changeDirection("Up");snake.moveUp();}
//            if(snake.getpreviousDirection().equals("Left")){ changeDirection("Left");snake.moveLeft();}
//            if(snake.getpreviousDirection().equals("Right")){changeDirection("Right");snake.moveRight();}}
    }

    public void moveDown() {
        if (!snake.getHeadUp()) {
            snake.moveDown();
        }
//        else{
//
//            if(snake.getpreviousDirection().equals("Down")){changeDirection("Down");snake.moveDown();}
//            if(snake.getpreviousDirection().equals("Left")){changeDirection("Left"); snake.moveLeft();}
//            if(snake.getpreviousDirection().equals("Right")){changeDirection("Right");snake.moveRight();}

    }




    public void collisionWApple()
    {
        if(snake.getheadX()==apple.getX1() && snake.getheadY()==apple.getY1())
        {
            score++;
            apple.setX((int)(Math.random()*40)*10);
            apple.setY((int)(Math.random()*40)*10);
            if(snake.getLastRight())
            {
                snake.addDot(snake.getLastX()-10,snake.getLastY());

            }
            else if(snake.getLastLeft())
            {
                snake.addDot(snake.getLastX()+10,snake.getLastY());



            }
            else if(snake.getLastUp())
            {
                snake.addDot(snake.getLastX(),snake.getLastY()+10);
            }
            else if(snake.getLastDown())
            {
                snake.addDot(snake.getLastX(),snake.getLastY()-10);
            }


        }


    }
        public void detectCollision()
            {
                if(snake.getheadX()>=CANVAS_WIDTH  || snake.getheadY()>=CANVAS_HEIGHT || snake.getheadX()<0
                || snake.getheadY()<0)
                {
                    gameOver=true;
                }
                if(snake.detectCollisionWSelf())
                {
                    gameOver=true;
                }
            }
         public String getDirection()
         {
             if(snake.getHeadDown())
             {
                 return "Down";
             }
             if(snake.getHeadRight())
             {
                 return "Right";
             }
             if(snake.getHeadUp())
             {
                 return "Up";
             }
             else
             {
                 return "Left";
             }
         }

         public void changeDirection(String inDirection)
         {
             if(inDirection.equals("Up"))
             {
                 snake.changeHeadDirection("Up");
             }
             if(inDirection.equals("Down"))
             {
                 snake.changeHeadDirection("Down");
             }
             if(inDirection.equals("Left"))
             {
                 snake.changeHeadDirection("Left");
             }
             if(inDirection.equals("Right"))
             {
                 snake.changeHeadDirection("Right");
             }
         }


public boolean getdontMove()
{
    return dontMove;
}




}
