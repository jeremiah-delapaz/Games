package com.company;

import java.util.ArrayList;

public class stick {
    private int check = 5; // used to both determine which limb to delete and whether the game is lost or not
    ArrayList<String> stickbody= new ArrayList <String>();

    public stick()
    {
       reset();
    }
    public void removeLimb()
        {
            stickbody.remove(check);
            check--;
        }
    public int getCheck()
    {
        return check;// in main, this is used to see if the user is all out of limbs to lose
    }



    public void reset()
    {
        check = 5;
        stickbody.clear();
        stickbody.add(" O \n");
        stickbody.add("/");
        stickbody.add("|");
        stickbody.add("\\ \n");
        stickbody.add(" | \n");
        stickbody.add("/ \\");
    }
    public String toString()
    {
        String print="";
        for(int i = 0; i<stickbody.size(); i++)
        {
            print+=stickbody.get(i);
        }
        return print;
    }

}

