package com.company;
import java.util.ArrayList;
import java.util.Scanner;
public class Main {

    public static void correct(int index, ArrayList<String> word,  ArrayList<String> chosenWord)
    {
        word.set(index,chosenWord.get(index) );// every time the for statement in the main detects an equivalant letter, this will change that letter

    }
    public static void reset (ArrayList<String> word,ArrayList<String> chosenWord, String randword, ArrayList<String>wordChoice )
    {

        word.clear();
        chosenWord.clear();


        for(int i = 0; i<randword.length(); i++)
        {
            word.add("_");// makes an array list full of ____ that will be changed later
            chosenWord.add(randword.substring(i,i+1));// makes an array list with word letters so it is easier to use
        }
    }

    public static void main(String[] args) {
	// write your code here
        String userword;
        boolean checkplayagain = true;// used for while loop, sees if user wants to play again
        boolean checkwin = true;// used to determine if game is over or not, if user wins or loses, this changes to false
        stick stickman = new stick();// creates a new object

        ArrayList<String> word = new ArrayList<String>();
        ArrayList<String> wordChoice= new ArrayList <String>();
        ArrayList<String> chosenWord= new ArrayList <String>();
        wordChoice.add("deodorant");
        wordChoice.add("pencil");
        wordChoice.add("receipt");
        wordChoice.add("chapstick");
        wordChoice.add("guitar");
        wordChoice.add("string");
        wordChoice.add("capo");
        wordChoice.add("case");
        wordChoice.add("phone");
        wordChoice.add("check");

        while(checkplayagain) {
            String randword = wordChoice.get((int)(Math.random()*10));//randomly selects word
            stickman.reset();
            reset(word, chosenWord, randword, wordChoice);
            int finish = 0;// checks if user has won
            checkwin = true;
            while (checkwin) {

                Scanner input = new Scanner(System.in);
                System.out.println("Choose a letter");
                userword = input.next();
                int checkcorrect = 0;
                for (int i = 0; i < randword.length(); i++) {// goes through and calls method to change arraylist to correctly guessed letters

                    if (userword.equals(chosenWord.get(i))) {
                        correct(i, word, chosenWord);
                        checkcorrect++;// just to show that a user has gotten a letter correct
                        finish++;// if this reaches length of word, game is won
                    }
                }
                if (checkcorrect == 0) {// what happens when it is wrong
                    System.out.println("wrong!");
                    stickman.removeLimb();
                }
                System.out.println(stickman);
                System.out.println(word);
                if (stickman.getCheck() < 0) {
                    System.out.println("you lost. the correct word was " + randword);
                    checkwin = false;
                } else if (finish == randword.length()) {
                    System.out.println("you win");
                    checkwin = false;
                }
            }
            System.out.println("do you want to play again? (Y/N)");
            Scanner input = new Scanner(System.in);
            String checker = input.next();
            if(checker.equals("N"))
            {
                checkplayagain = false;
            }

        }
    }
}
